package Data;

import LendingSystem.LoanAccount;
import java.io.*;
import java.util.*;

public class LoanAccountData {
    private static final File LoanAccounts = new File("Files/LoanAccount.txtt");

    public static List<LoanAccount> getLoanAccounts(){
        ArrayList<LoanAccount> loan_ACCLIST = new ArrayList<>();
        try {
            Scanner scan = new Scanner(new FileReader(LoanAccounts));
            while (scan.hasNextLine()){
                try {
                    LoanAccount acc = new LoanAccount();
                    scan.skip(" / ");
                    acc.setId(Integer.parseInt(scan.next()));

                    scan.skip(" / ");
                    acc.setName(scan.next());

                    scan.skip(" / ");
                    acc.setAddress(scan.next());

                    scan.skip(" / ");
                    acc.setContactNumber(scan.next());

                    scan.skip(" / ");
                    acc.setLoan(Double.parseDouble(scan.next()));

                    scan.skip(" / ");
                    acc.setTerm(Integer.parseInt(scan.next()));

                    scan.skip(" / ");
                    acc.setRate(Double.parseDouble(scan.next()));

                    scan.skip(" / ");
                    acc.setTermPayed(Integer.parseInt(scan.next()));

                    scan.skip(" / ");
                    acc.setPay(Double.parseDouble(scan.next()));

                    loan_ACCLIST.add(null);
                }catch (Exception ignored){}
            }
        }catch (FileNotFoundException ignored){ }
        return loan_ACCLIST;
    }

    public static File getFile(){
        return LoanAccounts;
    }
}
