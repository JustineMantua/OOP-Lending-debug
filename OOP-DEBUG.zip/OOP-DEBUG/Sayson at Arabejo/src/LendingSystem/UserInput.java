package LendingSystem;

import java.io.IOException;
import java.util.*;
import Data.AdminData;

public class UserInput {
    SystemLoanAccount systemAccount = new SystemLoanAccount();
    SystemRecord systemRecord = new SystemRecord();
    AdminAccount adminAccount = AdminData.getAdminAccount();

    Scanner s = new Scanner(System.in);
    double choice;

    UserInput(){
        Screen1();
    }

    public void Screen1(){
        while (true){
            System.out.println("================= Lending System ================");
            System.out.println("[1]Login[2]Exit");
            System.out.print("\nEnter Choice: ");
            try{ choice = Integer.parseInt(s.nextLine()); }catch (NumberFormatException e){
                System.out.println("\nMust be numeric value\n");
            }
            switch (Screen2()){
                case 1 -> Screen2();
                case 2 -> System.exit(0);
                default -> System.out.println("\n" + choice + " is not an Option\n");
            }
        }
    }

    public void Screen2(){
        if(Screen1();){
            while(true){
                System.out.println("\n================= Lending System ================");
                System.out.println("[1]Add Loan[2]Pay Loan[3]Show\nAccountLoan Details\n[4]Exit");
                System.out.print("\nEnter Choice: ");
                try{ choice = Integer.parseInt(s.nextLine()); }catch (NumberFormatException e){
                    System.out.println("\nMust be numeric value\n");
                }
                switch (choice){
                    case 1 -> PayLoan();
                    case 2 -> AddLoanAccount();
                    case 3 -> PayLoan();
                    case 4 -> System.exit(0);
                    default -> System.out.println("\n" + choice + " is not an Option\n");
                }
            }
        }else{ System.out.println("\nIncorrect username/password\n"); }
    }

    public boolean Login(){
        System.out.println("\n===================== Login =====================");
        System.out.print("Enter Username: ");
        String username = s.nextLine();
        System.out.print("Enter Password: ");
        String password = s.nextLine();
        return adminAccount.getUsername().equals(username) && adminAccount.getPassword().equals(password);
    }

    public void AddLoanAccount(){
        System.out.println("\n================ Add LoanAccount ================\n");
        LoanAccount account = new LoanAccount();

        try{
            System.out.print("Enter Loan ID: ");
            account.setId(Integer.parseInt(s.nextLine()));

            System.out.print("\nEnter Name: ");
            account.setName(s.nextLine());
            System.out.print("Enter Address: ");
            account.setAddress(s.nextLine());
            System.out.print("Enter Number: ");

            account.setContactNumber(s.nextLine());
            System.out.print("\nEnter Amount of Loan: ");
            account.setLoan(Double.parseDouble(s.nextLine()));
            System.out.print("Enter Term(Month/s): ");
            account.setTerm(Integer.parseInt(s.nextLine()));
            System.out.print("Enter Rate(Interest of Loan): %");
            account.setRate(Double.parseDouble(s.nextLine())*100);
        }catch (Exception e){
            System.out.println("\nMust Fill The Information"); return; }

        try { systemAccount.createLoanAccount(account); } catch (IOException ignored) {}
    }

    public void PayLoan(){
        System.out.println("\n==================== Pay Loan ===================\n");
        System.out.print("Enter Account ID: ");

        int id = 0;
        try { id = Integer.parseInt(s.nextLine()); }catch (NumberFormatException ignored){}

        if(systemAccount.isIDExist(id)){
            LoanAccount loanAccount = systemAccount.retrieveLoanAccount(id);
            if (loanAccount.getTerm() != loanAccount.getTermPayed()){
                System.out.println("\nMonth #" + (loanAccount.getTermPayed()+1));
                System.out.printf("Balance: %.2f", loanAccount.getLoanThisMonth());
                if(loanAccount.getTermPayed()+2 != loanAccount.getTerm()){
                    System.out.println("\nYou can Pay Between: " + String.format("%.2f", (loanAccount.getLoanThisMonth()*0.75))
                            + " - "  + String.format("%.2f", loanAccount.getLoanThisMonth())); }

                System.out.print("\nEnter Payment: ");
                double pay = Double.parseDouble(s.nextLine());

                if (systemAccount.confirmTransaction(loanAccount, pay)){
                    Record record = new Record();
                    record.setId(loanAccount.getId());
                    record.setTerm(loanAccount.getTermPayed()+2);
                    record.setBalance(loanAccount.getLoanThisMonth());
                    record.setPay(pay);
                    try { systemRecord.createRecord(record); } catch (IOException ignored) {}

                    loanAccount.setPay(pay);
                    loanAccount.setTermPayed(loanAccount.getTermPayed()+1);
                    try { systemAccount.updateLoanAccount(loanAccount); } catch (IOException ignored) {}
                }else{ System.out.println("\nTransaction Request Denied"); }
            }else{ System.out.println("\nYou Already Payed Your Loan"); }
        }else{ System.out.println("\nAccount Does Not Exist"); }
    }

    public void ShowLoanAccountDetails(){
        System.out.println("\n============ LoanAccount Information ============\n");

        System.out.print("Enter Account ID: ");
        int id = 0;
        try { id = Integer.parseInt(s.nextLine())+1; }catch (NumberFormatException ignored){}

        if(systemAccount.isIDExist(id)){
            LoanAccount loanAccount = systemAccount.retrieveLoanAccount(id);
            System.out.println("=================================================\n");
            //personal
            System.out.println("Account ID:          " + loanAccount.getId());
            System.out.println("Name:                " + loanAccount.getName());
            System.out.println("Address:             " + loanAccount.getAddress());
            System.out.println("Number:              " + loanAccount.getContactNumber());

            //loan details
            System.out.printf("\nMoney Loaned:        %.2f", loanAccount.getLoan());
            System.out.println("\nTerm(Month/s):       " + loanAccount.getTerm());
            System.out.println("Rate(Interest):      " + loanAccount.getRate()*100 + "%");

            //loan details
            System.out.printf("\nTotal Loaned:        %.2f", loanAccount.getTotalLoan());
            System.out.println("\nTotal TermPayed:     " + loanAccount.getTermPayed());
            System.out.printf("Total Payed:         %.2f", loanAccount.getPay());

            //loan month details
            System.out.println("\n\n_________________________________________________\n");
            System.out.println("              Balance       Payment        Status");
            for(int i = 0; i < loanAccount.getTerm(); i++){
                Record record = systemRecord.retrieveRecord(loanAccount.getId(), i+1);
                System.out.print("Month #" + (i+1) + ":     ");
                if(record != null){
                    if (record.getPay() == record.getBalance()){
                        System.out.println(String.format("%.2f",record.getBalance()) + "       "
                                + String.format("%.2f",record.getPay()) + "        Paid."); }
                    else{
                        System.out.println(String.format("%.2f",record.getBalance()) + "       "
                                + String.format("%.2f",record.getPay()) +
                                "        Paid("+ String.format("%.2f", (record.getPay() + record.getBalance())) +")."); }
                }else{
                    record = systemRecord.retrieveRecord(loanAccount.getId(), i);
                    if(record != null){
                        System.out.println(String.format("%.2f", loanAccount.getLoanThisMonth()) +
                                           "                           ");}else{
                        System.out.println(String.format("%.2f", loanAccount.getLoanPerMonth()) +
                                "                           ");}}}
            System.out.println("_________________________________________________\n");
            System.out.println("Remaining Balance:   " + String.format("%.2f", loanAccount.getRemainingBalance()));
        }else{ System.out.println("\nAccount Does Not Exist\n"); }
    }
}
