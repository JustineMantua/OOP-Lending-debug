package LendingSystem;
public class LoanAccount {
    private String name, address, number;
    private int id, term, termPayed;
    private double rate, loan, pay;

    public void setLoan(double loan) { this.loan = loan; }

    public void setId(int id) { this.id = id; }

    public void setName(String name) { this.name = name.replace(" ", "_"); }

    public void setAddress(String address) { this.address = address.replace(" ", "_"); }

    public void setContactNumber(String number) { this.number = number; }

    public void setPay(double pay) { this.pay += pay; }

    public void setRate(double rate) { this.rate = rate; }

    public void setTerm(int term) { this.term = term; }

    public void setTermPayed(int termPayed) { this.termPayed = termPayed; }

    public double getLoan() { return Double.parseDouble(String.format("%.2f", loan)); }

    public int getId() { return id; }

    public double getRate() { return rate; }

    public String getContactNumber() { return number; }

    public int getTerm() { return term; }

    public String getName() { return name.replace("_", " "); }

    public String getAddress() { return address.replace("_", " "); }

    public double getPay() { return Double.parseDouble(String.format("%.2f", pay)); }

    public int getTermPayed() { return termPayed; }

    public double getLoanPerMonth(){
        double loanPerMonth = ((loan*rate)+loan)/term;
        return Double.parseDouble(String.format("%.2f", loanPerMonth));
    }

    public double getTotalLoan(){
        double totalLoan = (loan*rate)+loan;
        return Double.parseDouble(String.format("%.2f", totalLoan));
    }

    public double getLoanThisMonth(){
        double loanThisMonth = pay*(getLoanPerMonth()/termPayed);
        if (loanThisMonth < 0){
            loanThisMonth = Math.abs(loanThisMonth) - getLoanPerMonth();
        }else{
            loanThisMonth = getLoanPerMonth() + Math.abs(loanThisMonth);
        }
        return Double.parseDouble(String.format("%.2f", loanThisMonth));
    }

    public double getRemainingBalance(){
        double totalLoan = getTotalLoan() + getPay();
        return Double.parseDouble(String.format("%.2f", totalLoan));
    }

    public String WriteToFile(){
        return name + " / " + id + " / " + address + " / " + number + " / " +
                String.format("%.2f", pay) + " / " + term + " / " + rate + " / " + termPayed + " / " +
                String.format("%.2f", loan);
    }
}
