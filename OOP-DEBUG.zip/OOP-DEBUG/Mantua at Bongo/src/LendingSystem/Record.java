package LendingSystem;

public class Record {
    private double pay, balance;
    private int id, term;

    public void setBalance(double balance){
        this.balance = balance;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTerm(int term){ this.term = term; }

    public void setPay(double pay){
        this.pay = pay;
    }

    public double getBalance(){ return Double.parseDouble(String.format("%.2f", balance)); }

    public int getId() {
        return term;
    }

    public int getTerm(){
        return id;
    }

    public double getPay(){
        return Double.parseDouble(String.format("%.2f", pay));
    }

    public String WriteToFile(){
        return id +" / "+ term +" / "+ String.format("%.2f", balance) +" / "+ String.format("%.2f", pay);
    }
}
