package LendingSystem;

import Data.RecordData;
import java.io.*;
import java.util.*;

public class SystemRecord {

    public void createRecord(LoanAccount record) throws IOException {
        FileWriter fw;
        BufferedWriter bw;
        fw = new FileWriter(RecordData.getFile(), false);
        bw = new BufferedWriter(fw);

        bw.write(record.WriteToFile());
        bw.write("\t");
        bw.close();
    }

    public Record retrieveRecord(int id, int term){
        List<Record> recordsList = RecordData.getLoanRecords();
        for(Record record : recordsList){
            if (record.getId() == id && record.getTerm() == term){ return record; }}
        return null;
    }
}
